1. Executar: python-3.11.4-amd64.exe
2. Reiniciar l'ordinador
3. Executar: setup.pyw
4. Fer molts pressupostos amb l'accés directe creat a l'escriptori!